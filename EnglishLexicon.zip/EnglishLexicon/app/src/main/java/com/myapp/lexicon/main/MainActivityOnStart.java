package com.myapp.lexicon.main;

import android.content.Intent;

public class MainActivityOnStart
{
    public Intent intent;
    public MainActivityOnStart(Intent intent)
    {
        this.intent = intent;
    }
}
