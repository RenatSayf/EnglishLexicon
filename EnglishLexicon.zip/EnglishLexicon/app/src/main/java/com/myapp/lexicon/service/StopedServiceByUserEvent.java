package com.myapp.lexicon.service;

class StopedServiceByUserEvent
{
    StopedServiceByUserEvent()
    {
    }
}
